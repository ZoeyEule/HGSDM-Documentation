# HGSDM Example Project

Copyright WildMods 2026 All Rights Reserved.

This project requires WildMods HGSDM 1.0.1 installed for Unreal Engine 5.8 through Fab/Epic Games Launcher. It deliberately contains no copy of the plugin.

Open `HGSDM_ExampleProject.uproject`. The project enables `WildMods_SSDM` and opens the showroom distributed by that installed engine plugin. If Unreal reports the plugin missing, install HGSDM for UE5.8 and reopen.

Qualified configuration: Windows, Win64, DX12, SM6, deferred renderer.
